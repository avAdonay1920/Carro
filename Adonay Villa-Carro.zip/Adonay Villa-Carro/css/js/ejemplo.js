var hola= document.querySelector(".letra")
hola.addEventListener('click', cambio)
function cambio(){
    hola.style.color='#FF00FF';
}
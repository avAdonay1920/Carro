  
var contenedor  = document.querySelector(".contenedor")
var rueda1= document.querySelector(".rueda1")
var rueda2= document.querySelector(".rueda2")
var luces= document.querySelector(".luces")
var sprite= document.querySelector(".sprite")

 
contenedor.addEventListener('click' , contenedorMover)


function contenedorMover(){
    contenedor.classList.add('contenedorMover')
    rueda1.classList.add('ruedaMover1')
    rueda2.classList.add('ruedaMover2')
    luces.classList.remove('lucesOculto')
    luces.classList.add('lucesMover')
    sprite.classList.remove('spriteOculto')
    sprite.classList.add('spriteMover')
}